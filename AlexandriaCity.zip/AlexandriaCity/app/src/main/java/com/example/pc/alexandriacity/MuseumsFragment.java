package com.example.pc.alexandriacity;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class MuseumsFragment extends Fragment {


    public MuseumsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_categories_list, container, false);

        //Create an array of list for museums
        ArrayList<Categories> museums = new ArrayList<Categories>();

        museums.add(new Categories(getString(R.string.museum_one1), getString(R.string.museum_one), R.drawable.nationalmuseum));
        museums.add(new Categories(getString(R.string.museume_two2), getString(R.string.museume_two), R.drawable.royaljewl));
        museums.add(new Categories(getString(R.string.museume_three3), getString(R.string.museume_three), R.drawable.cavafy));
        museums.add(new Categories(getString(R.string.museum_four4), getString(R.string.museum_four), R.drawable.shona));
        museums.add(new Categories(getString(R.string.museum_five5), getString(R.string.museum_five), R.drawable.romantheater));
        museums.add(new Categories(getString(R.string.museum_six6), getString(R.string.museum_six), R.drawable.pillar));
        museums.add(new Categories(getString(R.string.museum_seven7), getString(R.string.museum_seven), R.drawable.qaitbay));
        museums.add(new Categories(getString(R.string.museum_eight8), getString(R.string.museum_eight), R.drawable.farouk));

        // Create an {@link ArrayAdapter}, whose data source is a list of Strings. The
        // This list item layout contains a single {@link TextView}, which the adapter will set to
        // display a single item.
        CategoriesAdapter itemsAdapter =
                new CategoriesAdapter(getActivity(), museums);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_categories_listlist.xml layout file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
        // {@link ListView} will display list items for each word in the list of museums.
        // Do this by calling the setAdapter method on the {@link ListView} object and pass in
        // 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.
        listView.setAdapter(itemsAdapter);

        return rootView;
    }

}
