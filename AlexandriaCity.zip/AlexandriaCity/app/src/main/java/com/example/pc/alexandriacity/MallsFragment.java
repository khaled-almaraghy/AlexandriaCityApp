package com.example.pc.alexandriacity;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class MallsFragment extends Fragment {

    public MallsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_categories_list, container, false);

        //Create an array of list for malls
        ArrayList<Categories> malls = new ArrayList<Categories>();

        malls.add(new Categories(getString(R.string.mall_one1), getString(R.string.mall_one), R.drawable.san));
        malls.add(new Categories(getString(R.string.mall_two2), getString(R.string.mall_two), R.drawable.greenplaza));
        malls.add(new Categories(getString(R.string.mall_three3), getString(R.string.mall_three), R.drawable.citycenter));
        malls.add(new Categories(getString(R.string.mall_four4), getString(R.string.mall_four), R.drawable.mirage));
        malls.add(new Categories(getString(R.string.mall_five5), getString(R.string.mall_five), R.drawable.fathalla));
        malls.add(new Categories(getString(R.string.mall_six6), getString(R.string.mall_six), R.drawable.carrefour));
        malls.add(new Categories(getString(R.string.mall_seven7), getString(R.string.mall_seven), R.drawable.deepmall));
        malls.add(new Categories(getString(R.string.mall_eight8), getString(R.string.mall_eight), R.drawable.orouba));

        // Create an {@link ArrayAdapter}, whose data source is a list of Strings. The
        // This list item layout contains a single {@link TextView}, which the adapter will set to
        // display a single item.
        CategoriesAdapter itemsAdapter =
                new CategoriesAdapter(getActivity(), malls);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_categories_list.xml.xml layout file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
        // {@link ListView} will display list items for each word in the list of malls.
        // Do this by calling the setAdapter method on the {@link ListView} object and pass in
        // 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.
        listView.setAdapter(itemsAdapter);

        return rootView;
    }
}
